class Equipo {
  String id;
  String nombre;
  String lugardenacimiento;
  String dt;
  String year;
  String escudo;

  Equipo(this.id, this.nombre, this.lugardenacimiento, this.dt, this.year, this.escudo);
}