package com.example.dap_final_schatzyki

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
